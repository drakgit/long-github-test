﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Threading;
using System.IO;
using System.IO.Ports;
using Microsoft.Office.Core;
using Excel = Microsoft.Office.Interop.Excel;
using MasterDatabase;


namespace Job_Assignment
{
    public partial class Form1 : SQL_APPL
    {
        public static string MasterDatabase_Connection_Str = @"server=.;database=JOB_ASSIGNMENT_DB;Integrated Security = TRUE";
        public static string LeaveRegister_Connection_Str = @"server=.;database=SHIFT_REGISTER_DB;Integrated Security = TRUE";
        private string Cur_Path;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            maskedTextBox1.Text = DateTime.Now.ToString("dd/MM/yyyy");
            StatusLabel1.Text = "";
            StatusLabel2.Text = "";
            ProgressBar1.Visible = false;

            filterStatusLabel.Text = "";
            filterStatusLabel.Visible = false;
            showAllLabel.Text = "Show &All";
            showAllLabel.Visible = false;
            showAllLabel.IsLink = true;

            Cur_Path = Directory.GetCurrentDirectory();


            // BOM_Manage_Init();
            OpenXL = new Excel.Application();

            System.Globalization.CultureInfo oldCI = System.Threading.Thread.CurrentThread.CurrentCulture;
            System.Threading.Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("en-US");

            OpenXL.SheetsInNewWorkbook = 1;
            OpenXL.Visible = false;
            OpenXL.DisplayAlerts = false;

            tabControl1.TabPages.Remove(PLan_by_WST);
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
        }


    }
}

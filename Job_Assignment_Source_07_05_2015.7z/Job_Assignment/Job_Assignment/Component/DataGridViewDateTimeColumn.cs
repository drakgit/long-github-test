﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.ComponentModel;

namespace Job_Assignment
{
    public class DataGridViewDateTimeColumn : DataGridViewColumn
    {
        #region Constructor
        public DataGridViewDateTimeColumn(): base()
        {
            DataGridViewDateTimeCell temp = new DataGridViewDateTimeCell();
            CellTemplate = temp;
            ShowUpDown = false;
        }
        #endregion

        #region Properties
        [
        Browsable(false),
        DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)
        ]
        public override DataGridViewCell CellTemplate
        {
            get
            {
                return base.CellTemplate;
            }
            set
            {
                DataGridViewDateTimeCell dataGridViewDateTimeCell = value as DataGridViewDateTimeCell;
                if (value != null && dataGridViewDateTimeCell == null)
                {
                    throw new InvalidCastException("Value provided for CellTemplate must be of type DataGridViewDateTimeCell or derive from it.");
                }
                base.CellTemplate = value;
            }
        }
        private DataGridViewDateTimeCell DateTimeCellTemplate
        {
            get
            {
                return (DataGridViewDateTimeCell)this.CellTemplate;
            }
        }
        [Category("Behaviour")]
        [Description("Sets the custom format string for the DateTimePicker")]
        [DefaultValue("")]
        public string CustomFormat
        {
            get
            {
                if (this.DateTimeCellTemplate == null)
                {
                    throw new InvalidOperationException("Operation cannot be completed because this DataGridViewColumn does not have a CellTemplate.");
                }
                return this.DateTimeCellTemplate.CustomFormat;
            }
            set
            {
                this.DateTimeCellTemplate.CustomFormat = value;
                //todo: set custom format on row
                if (this.DataGridView != null)
                {
                    // Update all the existing DataGridViewNumericUpDownCell cells in the column accordingly.
                    DataGridViewRowCollection dataGridViewRows = this.DataGridView.Rows;
                    int rowCount = dataGridViewRows.Count;
                    for (int rowIndex = 0; rowIndex < rowCount; rowIndex++)
                    {
                        // Be careful not to unshare rows unnecessarily. 
                        // This could have severe performance repercussions.
                        DataGridViewRow dataGridViewRow = dataGridViewRows.SharedRow(rowIndex);
                        DataGridViewDateTimeCell dataGridViewCell = dataGridViewRow.Cells[this.Index] as DataGridViewDateTimeCell;
                        if (dataGridViewCell != null)
                        {
                            // Call the internal SetDecimalPlaces method instead of the property to avoid invalidation 
                            // of each cell. The whole column is invalidated later in a single operation for better performance.
                            dataGridViewCell.SetCustomFormat(rowIndex, value);
                        }
                    }
                    this.DataGridView.InvalidateColumn(this.Index);
                    // TODO: Call the grid's autosizing methods to autosize the column, rows, column headers / row headers as needed.
                }
            }
        }

        [Category("Appearance")]
        [Description("Sets the format for the DateTimePicker")]
        [DefaultValue(typeof(DateTimePickerFormat), "1")]
        public DateTimePickerFormat Format
        {
            get
            {
                if (this.DateTimeCellTemplate == null)
                {
                    throw new InvalidOperationException("Operation cannot be completed because this DataGridViewColumn does not have a CellTemplate.");
                }
                return this.DateTimeCellTemplate.Format;
            }
            set
            {
                this.DateTimeCellTemplate.Format = value;
                if (this.DataGridView != null)
                {
                    // Update all the existing DataGridViewNumericUpDownCell cells in the column accordingly.
                    DataGridViewRowCollection dataGridViewRows = this.DataGridView.Rows;
                    int rowCount = dataGridViewRows.Count;
                    for (int rowIndex = 0; rowIndex < rowCount; rowIndex++)
                    {
                        // Be careful not to unshare rows unnecessarily. 
                        // This could have severe performance repercussions.
                        DataGridViewRow dataGridViewRow = dataGridViewRows.SharedRow(rowIndex);
                        DataGridViewDateTimeCell dataGridViewCell = dataGridViewRow.Cells[this.Index] as DataGridViewDateTimeCell;
                        if (dataGridViewCell != null)
                        {
                            // Call the internal SetDecimalPlaces method instead of the property to avoid invalidation 
                            // of each cell. The whole column is invalidated later in a single operation for better performance.
                            dataGridViewCell.SetFormat(rowIndex, value);
                        }
                    }
                    this.DataGridView.InvalidateColumn(this.Index);
                    // TODO: Call the grid's autosizing methods to autosize the column, rows, column headers / row headers as needed.
                }
            }
        }

        [Category("Appearance")]
        [Description("If true the DateTimePicker shows the up/down button and not the calander")]
        [DefaultValue(false)]
        public bool ShowUpDown
        {
            get;
            set;
        }
        #endregion
    }
}

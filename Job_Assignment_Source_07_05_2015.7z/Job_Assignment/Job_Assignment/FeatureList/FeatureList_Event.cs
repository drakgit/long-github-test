﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MasterDatabase;


namespace Job_Assignment
{
    public partial class Form1 : SQL_APPL
    {

        private int SkillList_Index = 0;
        private int LineList_Index = 1;
        private int Line_DesciptionList_Index = 2;
        private int LineSkillRequestList_Index = 3;
        private int InputFromPlannerList_Index = 4;
        private int ProductionPlanByDate_Index = 5;
        private int ProductionPlanByWorkStation_Index = 6;
        private int WorkStationDescription_Index = 7;
        private int Tracking_Index = 7;
        const string TAB_TRACKING = "Tracking";

        private void ListProductionLine_Link_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            SkillList_Init();
        }

        private void lbl_Empl_Skill_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Empl_Skill_List_Init();
        }

        private void lbl_LineDescription_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Line_DesciptionList_Init();
        }

        private void lbl_LineSkillRequest_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            LineSkillRequestList_Init();
        }
        private void lbl_InputFromPlanner_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            InputFromPlannerList_Init();
        }
        private void lbl_ProductionPlanByDate_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            KeHoachSanXuatTheoNgayList_Init();
        }

        private void lbl_ProductionPlanByWorkStation_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            KeHoachSanXuatTheoTramList_Init();
            tabControl1.TabPages.Insert(tabControl1.TabPages.Count,PLan_by_WST);
        }
        private void lbl_WorkStationDescription_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            LineWorkStationMapping_Init();
        }
        private void llbTracking_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if (!tabControl1.TabPages.ContainsKey(TAB_TRACKING))
            {
                P007_P008_ucTracking uc = new P007_P008_ucTracking(ProgressBar1, StatusLabel1, StatusLabel2);
                uc.Dock = DockStyle.Fill;
                TabPage page = new TabPage(TAB_TRACKING);
                page.Name = TAB_TRACKING;
                page.Controls.Add(uc);
                tabControl1.TabPages.Add(page);
               // tabControl1.TabPages.Insert(Tracking_Index, page);
            }
            tabControl1.SelectedTab = tabControl1.TabPages[TAB_TRACKING];
        }

    }
}

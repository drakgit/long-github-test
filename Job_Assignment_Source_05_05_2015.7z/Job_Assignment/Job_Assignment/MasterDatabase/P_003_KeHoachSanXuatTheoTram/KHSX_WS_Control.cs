﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;
using System.IO.Ports;
using Microsoft.Office.Core;
using Excel = Microsoft.Office.Interop.Excel;
using MasterDatabase;
using System.Collections;

namespace Job_Assignment
{
    public partial class Form1 : SQL_APPL
    {
        public enum Empl_Status_Type
        {
            Avaliable = 0,
            Inuse = 1,
            Absent = 2,
        }

        public enum Empl_Shift_Name
        {
            Shift_HC = 0,
            Shift_1 = 1,
            Shift_2 = 2,
            Shift_3 = 3,
        }

        private void FormatRowInGridView(DataGridView gridview, int ColumIndex)
        {
            Color[] colors = new Color[5];

            colors[0] = Color.WhiteSmoke;
            colors[1] = Color.LightPink;
            colors[2] = Color.LightBlue;
            colors[3] = Color.LightGreen;
            colors[4] = Color.LightSalmon;

            Color CurrentColor = Color.White;
            int NextColor = 0;
            string PrevVal = "";

            foreach (DataGridViewRow row in KHSX_WS_dtgrid.Rows)
            {
                if ((string)row.Cells[ColumIndex].Value != PrevVal)
                {
                    PrevVal = (string)row.Cells[1].Value;

                    NextColor = (NextColor >= colors.Length - 1) ? 0 : (NextColor += 1);

                    CurrentColor = colors[NextColor];
                    row.DefaultCellStyle.BackColor = CurrentColor;
                }
                else
                {
                    row.DefaultCellStyle.BackColor = CurrentColor;
                }
            }
        }

        public bool Get_Shift_ID(string line_id, ref Empl_Shift_Name ShiftID, ref int ShiftPercent)
        {
            //TODO: Implement Get_Shift_ID

            //1. Get last shift of that line to see how many percent of shift was done
            Empl_Shift_Name LatestShift = Empl_Shift_Name.Shift_1;
            int LatestShiftPercent = 0;
            int CurrShiftPercent = 0;
            Empl_Shift_Name CurrentShift;

            foreach (DataRow row in KHSX_WS_dtb.Rows)
            {

                if (row["LineID"].ToString() == line_id)
                {
                    string val = (string)row["Shift_Name"];
                    //CurrentShift = (Empl_Shift_Name)(Convert.ToInt32(val));

                    CurrentShift = Empl_Shift_Name.Shift_HC;

                    switch (val)
                    {
                        case "Shift_HC":
                            CurrentShift = Empl_Shift_Name.Shift_HC;
                            break;

                        case "Shift_1":
                            CurrentShift = Empl_Shift_Name.Shift_1;
                            break;

                        case "Shift_2":
                            CurrentShift = Empl_Shift_Name.Shift_2;
                            break;

                        case "Shift_3":
                            CurrentShift = Empl_Shift_Name.Shift_3;
                            break;

                    }

                    CurrShiftPercent = (int)row["Shift_Percent"];

                    if ((CurrentShift > LatestShift) || (CurrShiftPercent > LatestShiftPercent))
                    {
                        LatestShift = CurrentShift;
                        LatestShiftPercent = CurrShiftPercent;
                        
                    }
                }
            }
            ShiftID = LatestShift;
            ShiftPercent = LatestShiftPercent;

            return  true;
        }

        /// <summary>
        /// Hôm qua làm WST nào. Hôm nay làm lại 
        /// 
        /// </summary>
        /// <param name="part"></param>
        /// <param name="line_id"></param>
        /// <param name="wst_id"></param>
        /// <param name="shift"></param>
        /// <returns></returns>
        private string Get_Empl_Last_Plan(DateTime date, string line_id, string wst_id, string shift)
        {
            if (date.DayOfWeek != DayOfWeek.Monday)
            {
                DateTime last_date = date.AddDays(-1);
            }
            else
            {
                DateTime last_date = date.AddDays(-2);
            }
            //TODO: Implement Get_Empl_Last_Plan
            return "";
        }

        /// <summary>
        /// Sắp nhân viên cho các line mới phát sinh
        /// </summary>
        /// <param name="part"></param>
        /// <param name="line_id"></param>
        /// <param name="wst_id"></param>
        /// <param name="shift"></param>
        /// <returns></returns>
        private string Get_Empl_New_Plan(DateTime date, string line_id, string wst_id, string shift)
        {
            //TODO: Implement Get_Empl_New_Plan
            return "";
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="empl_id"></param>
        /// <returns></returns>
        private string Get_Empl_Name(string empl_id)
        {
            //TODO: Implement Get_Empl_Name
            return "";
        }

        private DataTable Load_Avaliable_Empl_List(DateTime date)
        {
            string empl_id;
            DataTable all_empl_table = Load_All_Empl_Skill();

            Load_Leave_Register(date);

            foreach (DataRow row in all_empl_table.Rows)
            {
                empl_id = row["Empl_ID"].ToString().Trim();
                if (Is_Absent(empl_id, date))
                {
                    row["Status"] = Empl_Status_Type.Absent;
                    row["Shift_1"] = 0;
                    row["Shift_2"] = 0;
                    row["Shift_3"] = 0;
                    all_empl_table.Rows.Remove(row);
                }else{
                    row["Status"] = Empl_Status_Type.Avaliable;
                    row["Shift_1"] = 0;
                    row["Shift_2"] = 0;
                    row["Shift_3"] = 0;
                }
            }
            return null;
        }

        private bool Check_Empl_Able_for_Other_WST(string empl_Id)
        {
            //Todo: Check_Empl_Able_for_Other_WST
            return false;
        }

        private bool Set_New_WST(string empl_id, string shift)
        {
            //Todo: Set_New_WST
            return false;
        }
    }
}
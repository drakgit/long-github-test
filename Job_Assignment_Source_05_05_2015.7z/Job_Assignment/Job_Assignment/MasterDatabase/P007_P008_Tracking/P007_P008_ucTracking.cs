﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MasterDatabase;

namespace Job_Assignment
{
    public partial class P007_P008_ucTracking : UserControl
    {
        public P007_P008_ucTracking()
        {
            InitializeComponent();
            dtpFrom.Value = DateTime.Now;
            dtpTo.Value = DateTime.Now;
        }
        TrackingController contrl = new TrackingController();
        string[] hiddenColumns = { "Id", "TrackingType", "ModifyDate", "CreateDate"};
        string[] readonlyColumns = { "LineName", "WS_Name", "Empl_Name" };
        Dictionary<String, DataGridViewColumnType> columnTypes = new Dictionary<string, DataGridViewColumnType>();
        DataTable datasourceTracking = new DataTable();
        DataTable datasourceLine = null;

        private void P007_P008_ucTracking_Load(object sender, EventArgs e)
        {
            LoadData();
        }
        private String InitTrackingGridView(DataTable dt)
        {
            String ret = "";
            string[] columns = Utils.GetListColumn(dt);
            columnTypes.Add("LineID", DataGridViewColumnType.COMBOBOX);
            DataGridViewHelper.InitColumns(dgvTracking, columnTypes, columns, columns, hiddenColumns, readonlyColumns);

            //Init datasource for LineId
            ret = contrl.GetLineDescription(ref datasourceLine);
            if (String.IsNullOrEmpty(ret))
            {
                DataGridViewComboBoxColumn col = dgvTracking.Columns["LineID"] as DataGridViewComboBoxColumn;
                col.DataSource = datasourceLine;
                col.DisplayMember = "LineID";
                col.DataPropertyName = "LineID";
            }

            return ret;
        }
        private void LoadData()
        {
            String errs = contrl.GetData(dtpFrom.Value, dtpTo.Value, ref datasourceTracking);
            if (String.IsNullOrEmpty(errs))
            {
                if (dgvTracking.Columns.Count == 0)
                {
                    InitTrackingGridView(datasourceTracking);
                }
                BindingSource bs = new BindingSource();
                bs.DataSource = datasourceTracking;
                dgvTracking.DataSource = bs;
            }
            else
            {
                MessageBox.Show(errs, "Thông báo");
            }
        }

        private void btSearch_Click(object sender, EventArgs e)
        {
            LoadData();
        }

        private void btSave_Click(object sender, EventArgs e)
        {
            DataTable inputTable = ((BindingSource)dgvTracking.DataSource).DataSource as DataTable;
            contrl.SaveData(inputTable);
        }

        //private DataRow getDataTableRow()
        //{
        //    BindingSource bs = (BindingSource)dgvTracking.DataSource;
        //    DataTable inputTable = bs.DataSource as DataTable;
        //    var drv = bs. as DataRowView;
        //}

        private void btDuplicate_Click(object sender, EventArgs e)
        {
            BindingSource bs = (BindingSource)dgvTracking.DataSource;
            DataTable inputTable = bs.DataSource as DataTable;
            var drv = bs.Current as DataRowView;
            if (drv != null && drv.Row != null)
            {
                int currentIndex = inputTable.Rows.IndexOf(drv.Row);
                if (currentIndex != -1)
                {
                    DataRow toInsert = inputTable.NewRow();
                    toInsert.ItemArray = drv.Row.ItemArray.Clone() as object[];
                    inputTable.Rows.InsertAt(toInsert, currentIndex);
                }
            }
        }

        private void dgvTracking_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex > -1 && "LineID".Equals(dgvTracking.Columns[e.ColumnIndex].Name))
            {
                string lineId = dgvTracking[e.ColumnIndex, e.RowIndex].Value as string;
                DataRow[] searchRows = datasourceLine.Select("LineID='" + lineId + "'");
                if (searchRows.Length > 0)
                {
                    dgvTracking[e.ColumnIndex + 1, e.RowIndex].Value = searchRows[0]["LineName"];
                    //row["PartNumber"] = "A";
                    //row["LineName"] = searchRows[0]["LineName"];
                }
            }
        }
    }
}

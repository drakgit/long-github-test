﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Job_Assignment
{
    public enum DataGridViewColumnType
    {
        TEXT,
        DATE,
        NUMBER,
        COMBOBOX
    }
    public class DataGridViewHelper
    {
        public static DataGridViewColumn CreateColumn( DataGridViewColumnType columnType, String columnName, String columnText, bool isVisible, bool isReadOnly)
        {
            DataGridViewColumn col = null;
            switch (columnType)
            {
                case DataGridViewColumnType.COMBOBOX:
                    col = new DataGridViewComboBoxColumn();
                    ((DataGridViewComboBoxColumn)col).DisplayStyle = DataGridViewComboBoxDisplayStyle.DropDownButton;
                    break;
                case DataGridViewColumnType.DATE:
                case DataGridViewColumnType.NUMBER:
                default:
                    col = new DataGridViewTextBoxColumn();
                    break;
            }
            col.Name = columnName;
            col.HeaderText = columnText;
            col.Visible = isVisible;
            col.ReadOnly = isReadOnly;
    
            return col;
        }
        public static void InitColumns(DataGridView dgv, Dictionary<string, DataGridViewColumnType> columnTypes, string[] columnNames, string[] columnTexts, string[] hiddenColumns, string[] readonlyColumns)
        {
            dgv.AutoGenerateColumns = false;
            dgv.Columns.Clear();
            for (int i = 0; i < columnNames.Length; i++)
            {
                DataGridViewColumnType type = columnTypes.ContainsKey(columnNames[i]) ? columnTypes[columnNames[i]] :  DataGridViewColumnType.TEXT;
                bool isVisible = !hiddenColumns.Contains(columnNames[i]);
                bool isReadOnly = readonlyColumns.Contains(columnNames[i]);
                DataGridViewColumn col = CreateColumn(type, columnNames[i], columnTexts[i], isVisible, isReadOnly);
                dgv.Columns.Add(col);
            }

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Job_Assignment
{
    public class DataGridViewDateTimeCell : DataGridViewTextBoxCell
    {
        DateTimePickerFormat _format;
        string _customFormat;

        #region Constructor
        public DataGridViewDateTimeCell()
        {
        }
        #endregion
        #region 
        public DateTimePickerFormat Format
        {
            get
            {
                return this._format;
            }

            set
            {
                if (this._format != value)
                {
                    this._format = value;
                    if (OwnsEditingdateTimePicker(this.RowIndex))
                    {
                        this.EditingDateTimePicker.Format = value;
                    }
                    OnCommonChange();
                }
            }
        }
        public string CustomFormat
        {
            get
            {
                return this._customFormat;
            }

            set
            {
                this._customFormat = value;
                if (OwnsEditingdateTimePicker(this.RowIndex))
                {
                    this.EditingDateTimePicker.CustomFormat = value;
                }
            }
        }
        /// <summary>
        /// Returns the current DataGridView EditingControl as a DataGridViewNumericUpDownEditingControl control
        /// </summary>
        private DateTimePickerEditingControl EditingDateTimePicker
        {
            get
            {
                return this.DataGridView.EditingControl as DateTimePickerEditingControl;
            }
        }
        /// <summary>
        /// Determines whether this cell, at the given row index, shows the grid's editing control or not.
        /// The row index needs to be provided as a parameter because this cell may be shared among multiple rows.
        /// </summary>
        private bool OwnsEditingdateTimePicker(int rowIndex)
        {
            if (rowIndex == -1 || this.DataGridView == null)
            {
                return false;
            }
            DateTimePickerEditingControl dateTimePickerEditingControl = this.DataGridView.EditingControl as DateTimePickerEditingControl;
            return dateTimePickerEditingControl != null && rowIndex == ((IDataGridViewEditingControl)dateTimePickerEditingControl).EditingControlRowIndex;
        }
        /// <summary>
        /// Called when a cell characteristic that affects its rendering and/or preferred size has changed.
        /// This implementation only takes care of repainting the cells. The DataGridView's autosizing methods
        /// also need to be called in cases where some grid elements autosize.
        /// </summary>
        private void OnCommonChange()
        {
            if (this.DataGridView != null && !this.DataGridView.IsDisposed && !this.DataGridView.Disposing)
            {
                if (this.RowIndex == -1)
                {
                    // Invalidate and autosize column
                    this.DataGridView.InvalidateColumn(this.ColumnIndex);

                    // TODO: Add code to autosize the cell's column, the rows, the column headers 
                    // and the row headers depending on their autosize settings.
                    // The DataGridView control does not expose a public method that takes care of this.
                }
                else
                {
                    // The DataGridView control exposes a public method called UpdateCellValue
                    // that invalidates the cell so that it gets repainted and also triggers all
                    // the necessary autosizing: the cell's column and/or row, the column headers
                    // and the row headers are autosized depending on their autosize settings.
                    this.DataGridView.UpdateCellValue(this.ColumnIndex, this.RowIndex);
                }
            }
        }
        #endregion

        #region Overrides
        public override Type EditType
        {
            get
            {
                return typeof(DateTimePickerEditingControl);
            }
        }
        public override Type ValueType
        {
            get
            {
                // Return the type of the value that CalendarCell contains. 
                return typeof(DateTime);
            }
        }

        public override object DefaultNewRowValue
        {
            get
            {
                // Use the current date and time as the default value. 
                return DateTime.Now;
            }
        }
        public override void InitializeEditingControl(int rowIndex, object initialFormattedValue, DataGridViewCellStyle dataGridViewCellStyle)
        {
            // Set the value of the editing control to the current cell value. 
            base.InitializeEditingControl(rowIndex, initialFormattedValue, dataGridViewCellStyle);
            DateTimePickerEditingControl ctl = DataGridView.EditingControl as DateTimePickerEditingControl;
            
            // Use the default row value when Value property is null. 
            if (this.Value == null)
            {
                ctl.Value = (DateTime)this.DefaultNewRowValue;
            }
            else
            {
                ctl.Value = (DateTime)this.Value;
            }
        }

        protected override object GetFormattedValue(object value, int rowIndex, ref DataGridViewCellStyle cellStyle, System.ComponentModel.TypeConverter valueTypeConverter, System.ComponentModel.TypeConverter formattedValueTypeConverter, DataGridViewDataErrorContexts context)
        {
            if (value == null)
            {
                value = String.Empty;
                return base.GetFormattedValue(value, rowIndex, ref cellStyle, valueTypeConverter, formattedValueTypeConverter, context);
            }
            DataGridViewDateTimeColumn col = (DataGridViewDateTimeColumn)OwningColumn;
            if (col.Format == DateTimePickerFormat.Custom)
            {
                value = ((DateTime)value).ToString(col.CustomFormat);
            }
            else if (col.Format == DateTimePickerFormat.Long)
                value = ((DateTime)value).ToLongDateString();
            else if (col.Format == DateTimePickerFormat.Short)
                value = ((DateTime)value).ToShortDateString();
            else
                value = ((DateTime)value).ToLongTimeString();
            return base.GetFormattedValue(value, rowIndex, ref cellStyle, valueTypeConverter, formattedValueTypeConverter, context);
        }
        #endregion
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.ComponentModel;

namespace Job_Assignment
{
    public class DataGridViewDateTimeColumn : DataGridViewTextBoxColumn
    {
        #region Constructor
        public DataGridViewDateTimeColumn()
        {
            CellTemplate = new DataGridViewDateTimeCell();
            Format = DateTimePickerFormat.Long;
            ShowUpDown = false;
        }
        #endregion

        #region Properties
        public override DataGridViewCell CellTemplate
        {
            get
            {
                return base.CellTemplate;
            }
            set
            {
                DataGridViewDateTimeCell dataGridViewDateTimeCell = value as DataGridViewDateTimeCell;
                if (value != null && dataGridViewDateTimeCell == null)
                {
                    throw new InvalidCastException("Value provided for CellTemplate must be of type DataGridViewDateTimeCell or derive from it.");
                }
                base.CellTemplate = value;
            }
        }
        private DataGridViewDateTimeCell DateTimeCellTemplate
        {
            get
            {
                return (DataGridViewDateTimeCell)this.CellTemplate;
            }
        }
        [Category("Behaviour")]
        [Description("Sets the custom format string for the DateTimePicker")]
        [DefaultValue("")]
        public string CustomFormat
        {
            get
            {
                if (this.DateTimeCellTemplate == null)
                {
                    throw new InvalidOperationException("Operation cannot be completed because this DataGridViewColumn does not have a CellTemplate.");
                }
                return this.DateTimeCellTemplate.CustomFormat;
            }
            set
            {
                this.DateTimeCellTemplate.CustomFormat = value;
                //todo: set custom format on row
            }
        }

        [Category("Appearance")]
        [Description("Sets the format for the DateTimePicker")]
        [DefaultValue(typeof(DateTimePickerFormat), "1")]
        public DateTimePickerFormat Format
        {
            get
            {
                if (this.DateTimeCellTemplate == null)
                {
                    throw new InvalidOperationException("Operation cannot be completed because this DataGridViewColumn does not have a CellTemplate.");
                }
                return this.DateTimeCellTemplate.Format;
            }
            set
            {
                this.DateTimeCellTemplate.Format = value;
            }
        }

        [Category("Appearance")]
        [Description("If true the DateTimePicker shows the up/down button and not the calander")]
        [DefaultValue(false)]
        public bool ShowUpDown
        {
            get;
            set;
        }
        #endregion
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;
using System.IO.Ports;
using Microsoft.Office.Core;
using Excel = Microsoft.Office.Interop.Excel;
using MasterDatabase;
using System.Collections;

namespace Job_Assignment
{
    public partial class Form1 : SQL_APPL
    {
        public DataTable Leave_dtb = new DataTable();
        public DataSet Leave_ds = new DataSet();
        public SqlDataAdapter Leave_da;

        public DataTable Load_Leave_Register(DateTime select_date)
        {
            string sql_cmd = @"SELECT * FROM [SHIFT_REGISTER_DB].[dbo].[Leave_Register_DB]";
            sql_cmd += " WHERE [Date] = '" + select_date.ToString("dd MMM yyyy") + "'";

            if (Leave_dtb != null)
            {
                Leave_dtb.Clear();
            }
            Leave_dtb = Get_SQL_Data(LeaveRegister_Connection_Str, sql_cmd, ref Leave_da, ref Leave_ds);
            return KHSX_WS_dtb;
        }

        public bool Is_Absent(string empl_id, DateTime date)
        {
            string cur_empl;
            //TODO: Implement Is_Absent
            foreach (DataRow row in Leave_dtb.Rows)
            {
                cur_empl = row["Empl_ID"].ToString().Trim();
                if (empl_id == cur_empl)
                {
                    return true;
                }
            }
            return false;
        }
    }
}
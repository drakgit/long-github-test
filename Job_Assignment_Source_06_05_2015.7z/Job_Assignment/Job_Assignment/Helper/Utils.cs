﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace Job_Assignment
{
    public class Utils
    {
        public static String[] GetListColumn(DataTable dt)
        {
            String[] arr = new string[dt.Columns.Count];
            for (int i = 0; i < dt.Columns.Count; i++)
            {
                arr[i] = dt.Columns[i].ColumnName;
            }
            return arr;
        }
    }
}
